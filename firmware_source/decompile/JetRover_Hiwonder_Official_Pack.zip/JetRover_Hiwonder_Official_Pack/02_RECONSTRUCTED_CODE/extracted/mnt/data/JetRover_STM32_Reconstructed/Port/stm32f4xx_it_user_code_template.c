/* Paste the relevant bodies into CubeMX-generated stm32f4xx_it.c USER CODE blocks. */
#ifdef JETROVER_USE_STM32_HAL
#include "jetrover_app.h"
#include "tim.h"

extern JetRoverApp g_jetrover;
extern TIM_HandleTypeDef htim2, htim3, htim4, htim5, htim7;

void jetrover_TIM7_update_hook(void)
{
    if (__HAL_TIM_GET_FLAG(&htim7, TIM_FLAG_UPDATE) != RESET) {
        __HAL_TIM_CLEAR_FLAG(&htim7, TIM_FLAG_UPDATE);
        jetrover_app_control_tick_10ms(&g_jetrover);
    }
}

void jetrover_TIM5_overflow_hook(void) { jetrover_app_encoder_overflow_isr(&g_jetrover, 0); }
void jetrover_TIM2_overflow_hook(void) { jetrover_app_encoder_overflow_isr(&g_jetrover, 1); }
void jetrover_TIM4_overflow_hook(void) { jetrover_app_encoder_overflow_isr(&g_jetrover, 2); }
void jetrover_TIM3_overflow_hook(void) { jetrover_app_encoder_overflow_isr(&g_jetrover, 3); }
#endif
