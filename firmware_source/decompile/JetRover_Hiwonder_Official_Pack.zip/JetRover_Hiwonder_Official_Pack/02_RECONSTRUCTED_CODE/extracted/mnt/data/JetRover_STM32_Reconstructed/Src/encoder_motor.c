#include "encoder_motor.h"
#include <math.h>

#define PWM_LIMIT       1000.0f
#define PWM_DEAD_ZONE    250.0f
#define SPEED_NEW_WEIGHT   0.9f
#define SPEED_OLD_WEIGHT   0.1f

static float clampf_local(float v, float lo, float hi)
{
    return (v > hi) ? hi : ((v < lo) ? lo : v);
}

void encoder_motor_init(EncoderMotor *motor,
                        uint8_t motor_index,
                        float ticks_per_circle,
                        float rps_limit,
                        float kp,
                        float ki,
                        float kd,
                        EncoderMotorSetPulseFn set_pulse,
                        EncoderMotorFaultFn fault_active)
{
    if (!motor) return;
    motor->counter = 0;
    motor->overflow_num = 0;
    motor->ticks_overflow = 60000;
    motor->tps = 0.0f;
    motor->rps = 0.0f;
    motor->current_pulse = 0;
    pid_controller_init(&motor->pid_controller, kp, ki, kd);
    motor->ticks_per_circle = ticks_per_circle;
    motor->rps_limit = rps_limit;
    motor->set_pulse = set_pulse;
    motor->motor_index = motor_index;
    motor->fault_active = fault_active;
}

void encoder_motor_set_speed(EncoderMotor *motor, float target_rps)
{
    if (!motor) return;
    motor->pid_controller.set_point = clampf_local(target_rps,
                                                   -motor->rps_limit,
                                                   motor->rps_limit);
}

void encoder_motor_update_speed(EncoderMotor *motor, float period_s, int64_t timer_counter)
{
    if (!motor || period_s <= 0.0f || motor->ticks_per_circle <= 0.0f) return;

    const int64_t absolute_counter =
        timer_counter + motor->overflow_num * (int64_t)motor->ticks_overflow;
    const int64_t delta_count = absolute_counter - motor->counter;
    motor->counter = absolute_counter;

    const float instantaneous_tps = (float)delta_count / period_s;
    motor->tps = instantaneous_tps * SPEED_NEW_WEIGHT + motor->tps * SPEED_OLD_WEIGHT;
    motor->rps = motor->tps / motor->ticks_per_circle;
}

void encoder_motor_on_encoder_overflow(EncoderMotor *motor, bool counting_down)
{
    if (!motor) return;
    if (counting_down) {
        --motor->overflow_num;
    } else {
        ++motor->overflow_num;
    }
}

void encoder_motor_control(EncoderMotor *motor, float period_s)
{
    if (!motor || !motor->set_pulse || period_s <= 0.0f) return;

    float next_pulse = 0.0f;
    const bool fault = motor->fault_active ? motor->fault_active(motor) : false;

    /* The recovered firmware forces PWM to zero when its board-level guard is active. */
    if (!fault) {
        pid_controller_update(&motor->pid_controller, motor->rps, period_s);
        next_pulse = (float)motor->current_pulse + motor->pid_controller.output;
        next_pulse = clampf_local(next_pulse, -PWM_LIMIT, PWM_LIMIT);
    } else {
        pid_controller_reset(&motor->pid_controller);
    }

    const int applied = (fabsf(next_pulse) < PWM_DEAD_ZONE) ? 0 : (int)next_pulse;
    motor->set_pulse(motor, applied);
    motor->current_pulse = (int32_t)next_pulse;
}

void encoder_motor_stop(EncoderMotor *motor)
{
    if (!motor) return;
    motor->pid_controller.set_point = 0.0f;
    motor->current_pulse = 0;
    pid_controller_reset(&motor->pid_controller);
    if (motor->set_pulse) motor->set_pulse(motor, 0);
}
