#ifndef JETROVER_ENCODER_MOTOR_H
#define JETROVER_ENCODER_MOTOR_H

#include <stdbool.h>
#include <stdint.h>
#include "pid.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct EncoderMotor EncoderMotor;
typedef void (*EncoderMotorSetPulseFn)(EncoderMotor *motor, int pulse);
typedef bool (*EncoderMotorFaultFn)(const EncoderMotor *motor);

/*
 * Layout intentionally follows the structure recovered from RosRobotControllerM4.bin.
 * The callback appears at offset 0x44 in the 32-bit firmware.
 */
struct EncoderMotor {
    int64_t counter;
    int64_t overflow_num;
    int32_t ticks_overflow;
    float tps;
    float rps;
    int32_t current_pulse;
    PID_Controller pid_controller;
    float ticks_per_circle;
    float rps_limit;
    EncoderMotorSetPulseFn set_pulse;

    /* Reconstruction-only metadata; not part of the recovered 0x48-byte object. */
    uint8_t motor_index;
    EncoderMotorFaultFn fault_active;
};

void encoder_motor_init(EncoderMotor *motor,
                        uint8_t motor_index,
                        float ticks_per_circle,
                        float rps_limit,
                        float kp,
                        float ki,
                        float kd,
                        EncoderMotorSetPulseFn set_pulse,
                        EncoderMotorFaultFn fault_active);

void encoder_motor_set_speed(EncoderMotor *motor, float target_rps);
void encoder_motor_update_speed(EncoderMotor *motor, float period_s, int64_t timer_counter);
void encoder_motor_on_encoder_overflow(EncoderMotor *motor, bool counting_down);
void encoder_motor_control(EncoderMotor *motor, float period_s);
void encoder_motor_stop(EncoderMotor *motor);

#ifdef __cplusplus
}
#endif

#endif
