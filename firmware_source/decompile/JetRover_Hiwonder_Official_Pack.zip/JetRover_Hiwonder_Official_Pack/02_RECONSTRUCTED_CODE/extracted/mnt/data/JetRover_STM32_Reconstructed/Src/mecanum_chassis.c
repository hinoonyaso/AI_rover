#include "mecanum_chassis.h"

#define JETROVER_PI_F 3.14159265358979323846f

static float linear_speed_to_rps(const MecanumChassis *chassis, float speed_mm_s)
{
    if (!chassis || chassis->wheel_diameter_mm <= 0.0f) return 0.0f;
    return speed_mm_s / (JETROVER_PI_F * chassis->wheel_diameter_mm)
           * chassis->correction_factor;
}

/* Recovered/official JETAUTO motor sign and index mapping. */
static void jetauto_apply_wheel_rps(MecanumChassis *chassis,
                                    float rps_lh,
                                    float rps_lt,
                                    float rps_rh,
                                    float rps_rt)
{
    encoder_motor_set_speed(chassis->motors[3], -rps_lh);
    encoder_motor_set_speed(chassis->motors[2], -rps_lt);
    encoder_motor_set_speed(chassis->motors[0],  rps_rh);
    encoder_motor_set_speed(chassis->motors[1],  rps_rt);
}

void mecanum_chassis_init(MecanumChassis *chassis,
                          EncoderMotor *m1,
                          EncoderMotor *m2,
                          EncoderMotor *m3,
                          EncoderMotor *m4,
                          float wheel_diameter_mm,
                          float shaft_length_mm,
                          float wheelbase_mm,
                          float correction_factor)
{
    if (!chassis) return;
    chassis->motors[0] = m1;
    chassis->motors[1] = m2;
    chassis->motors[2] = m3;
    chassis->motors[3] = m4;
    chassis->wheel_diameter_mm = wheel_diameter_mm;
    chassis->shaft_length_mm = shaft_length_mm;
    chassis->wheelbase_mm = wheelbase_mm;
    chassis->correction_factor = correction_factor;
}

void mecanum_chassis_set_velocity(MecanumChassis *chassis,
                                  float vx_mm_s,
                                  float vy_mm_s,
                                  float angular_rate_rad_s)
{
    if (!chassis) return;

    const float rotation_linear_mm_s = angular_rate_rad_s *
        (chassis->wheelbase_mm * 0.5f + chassis->shaft_length_mm * 0.5f);

    const float v1 = vx_mm_s - vy_mm_s - rotation_linear_mm_s;
    const float v2 = vx_mm_s + vy_mm_s + rotation_linear_mm_s;
    const float v3 = vx_mm_s - vy_mm_s + rotation_linear_mm_s;
    const float v4 = vx_mm_s + vy_mm_s - rotation_linear_mm_s;

    jetauto_apply_wheel_rps(chassis,
                            linear_speed_to_rps(chassis, v1),
                            linear_speed_to_rps(chassis, v4),
                            linear_speed_to_rps(chassis, v2),
                            linear_speed_to_rps(chassis, v3));
}

void mecanum_chassis_stop(MecanumChassis *chassis)
{
    if (!chassis) return;
    for (unsigned i = 0; i < 4; ++i) {
        if (chassis->motors[i]) encoder_motor_set_speed(chassis->motors[i], 0.0f);
    }
}
