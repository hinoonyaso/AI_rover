/*
 * STM32F407 HAL integration template.
 * Copy into Core/Src of a CubeMX project and adapt PWM channels/pins to your exact board schematic.
 * Encoder timer mapping below is confirmed by Hiwonder documentation and the uploaded firmware:
 *   Motor1 -> TIM5, Motor2 -> TIM2, Motor3 -> TIM4, Motor4 -> TIM3
 * Control/PID update -> TIM7 every 10 ms
 */
#ifdef JETROVER_USE_STM32_HAL

#include "jetrover_port.h"
#include "main.h"
#include "tim.h"
#include "usart.h"

extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;
extern TIM_HandleTypeDef htim5;
extern TIM_HandleTypeDef htim7;
extern TIM_HandleTypeDef htim8;

static TIM_HandleTypeDef *encoder_timer(uint8_t motor_index)
{
    switch (motor_index) {
    case 0: return &htim5;
    case 1: return &htim2;
    case 2: return &htim4;
    case 3: return &htim3;
    default: return 0;
    }
}

void jetrover_port_init(void)
{
    HAL_TIM_Encoder_Start(&htim5, TIM_CHANNEL_ALL);
    HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
    HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);
    HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);
    HAL_TIM_Base_Start_IT(&htim7);

    /* Start the exact PWM channels used by your board after checking the schematic/CubeMX project. */
}

void jetrover_port_set_motor_pwm(uint8_t motor_index, int pulse)
{
    /*
     * IMPORTANT: do not guess motor channel polarity here.
     * The uploaded binary initializes TIM1 and TIM8 for 8 directional PWM outputs.
     * Hiwonder's public example confirms Motor1 uses TIM1 CH4 for forward and CH3 for reverse.
     * Fill Motor2-4 from the exact board schematic / original CubeMX .ioc before flashing.
     */
    const uint32_t duty = (uint32_t)(pulse < 0 ? -pulse : pulse);
    if (motor_index == 0u) {
        if (pulse > 0) {
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 0);
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, duty);
        } else if (pulse < 0) {
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, 0);
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, duty);
        } else {
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 0);
            __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, 0);
        }
        return;
    }

    /* Fail-safe: unverified mappings never drive motors. */
    (void)duty;
}

int64_t jetrover_port_read_encoder_counter(uint8_t motor_index)
{
    TIM_HandleTypeDef *htim = encoder_timer(motor_index);
    return htim ? (int64_t)__HAL_TIM_GET_COUNTER(htim) : 0;
}

bool jetrover_port_encoder_counting_down(uint8_t motor_index)
{
    TIM_HandleTypeDef *htim = encoder_timer(motor_index);
    return htim ? (__HAL_TIM_IS_TIM_COUNTING_DOWN(htim) != 0) : false;
}

bool jetrover_port_motor_fault_active(uint8_t motor_index)
{
    (void)motor_index;
    /* Binary checks GPIOD bit 3 before applying motor PID. Verify board signal meaning first. */
#ifdef MOTOR_FAULT_GPIO_Port
    return HAL_GPIO_ReadPin(MOTOR_FAULT_GPIO_Port, MOTOR_FAULT_Pin) == GPIO_PIN_SET;
#else
    return false;
#endif
}

int jetrover_port_uart_write(const uint8_t *data, size_t len)
{
    if (!data || len == 0u) return 0;
    /* The recovered image contains several UARTs. Bind this to the host-RRC UART used by your board. */
#ifdef JETROVER_HOST_UART_HANDLE
    return HAL_UART_Transmit(&JETROVER_HOST_UART_HANDLE, (uint8_t *)data, (uint16_t)len, 100) == HAL_OK
           ? (int)len : -1;
#else
    return -1;
#endif
}

uint32_t jetrover_port_millis(void)
{
    return HAL_GetTick();
}

#endif /* JETROVER_USE_STM32_HAL */
