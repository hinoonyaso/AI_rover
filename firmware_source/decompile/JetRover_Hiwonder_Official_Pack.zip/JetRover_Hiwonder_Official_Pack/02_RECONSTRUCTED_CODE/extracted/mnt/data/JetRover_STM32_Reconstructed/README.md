# JetRover STM32 reconstructed C core

This package is a clean-room functional reconstruction from the uploaded `RosRobotControllerM4.hex/.bin` decompile, cross-checked against Hiwonder's public STM32 documentation.

## What is actually reconstructed

High-confidence, testable parts:

- PID structure/layout and update law
- Encoder motor object layout and 10 ms speed/PID loop
- Encoder overflow accounting and 0.9/0.1 speed low-pass filter
- PWM clamp ±1000 and dead-zone ±250
- JETAUTO/Mecanum inverse kinematics and motor sign/index mapping
- RRC frame format: `AA 55 function length payload crc`
- RRC function IDs 0..9
- CRC-8 algorithm matching the firmware lookup table exactly
- CMSIS-RTOS task names recovered from firmware strings/attributes

## What is intentionally NOT guessed

The HEX does not preserve original CubeMX `.ioc`, source-level GPIO labels, comments, or every type name. Therefore this package does **not** pretend that all of the following are known:

- exact Motor2..4 PWM timer channel/polarity mapping for every controller revision
- exact meaning of the GPIOD bit-3 safety/fault input seen in the binary
- exact compact IMU payload encoding for this firmware generation
- exact motor command payload schema for every RRC firmware revision
- exact JetRover wheel/track/wheelbase dimensions for your mechanical revision

Those are left behind an explicit port/config layer rather than fabricated.

## Host test

```bash
make test
```

The host test verifies CRC framing/parser and basic Mecanum target-speed generation.

## STM32CubeMX integration

1. Create/open an STM32F407VET6 project using the actual Hiwonder board pinout.
2. Keep CubeMX-generated clock/GPIO/DMA/UART/TIM init code.
3. Add `Inc/` and `Src/` to the project.
4. Copy/adapt `Port/jetrover_port_stm32f407_template.c`.
5. Define `JETROVER_USE_STM32_HAL`.
6. Use TIM7 as a 10 ms control tick.
7. Encoder mapping confirmed by Hiwonder docs: M1=TIM5, M2=TIM2, M3=TIM4, M4=TIM3.
8. Confirm PWM pin/channel mapping from the exact board schematic before enabling Motor2..4.
9. Confirm geometry/motor constants in `Inc/jetrover_config.h` against the actual JetRover.
10. Only after bench testing with wheels lifted should the firmware be flashed for driving tests.

## Important safety note

`Port/jetrover_port_stm32f407_template.c` intentionally drives only the documented Motor1 mapping and leaves unverified Motor2..4 outputs fail-safe OFF. This is deliberate: guessing H-bridge direction channels can short/brake the motor driver or cause immediate unintended motion.

## Recovered task names

The uploaded image contains these literal RTOS thread names:

- `defaultTask`
- `oled_task`
- `bluetooth_task`
- `gui_task`
- `app_task`
- `imu_task`
- `sbus_rx_task`
- `packet_rx_task`
- `packet_tx_task`

It also contains synchronization object names such as `mpu6050_data_ready`, `packet_rx_not_empty`, `packet_tx_queue`, `battery_check_timer`, and `buzzer_timer`.

See `reference/decompile_name_map.csv` for address-to-name reconstruction evidence.
