#ifndef JETROVER_APP_H
#define JETROVER_APP_H

#include <stddef.h>
#include <stdint.h>
#include "encoder_motor.h"
#include "mecanum_chassis.h"
#include "rrc_protocol.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    EncoderMotor motors[4];
    MecanumChassis chassis;
    RRC_Parser packet_parser;
} JetRoverApp;

void jetrover_app_init(JetRoverApp *app);
void jetrover_app_set_cmd_vel(JetRoverApp *app, float vx_m_s, float vy_m_s, float wz_rad_s);
void jetrover_app_stop(JetRoverApp *app);
void jetrover_app_control_tick_10ms(JetRoverApp *app);
void jetrover_app_encoder_overflow_isr(JetRoverApp *app, uint8_t motor_index);
void jetrover_app_feed_uart(JetRoverApp *app, const uint8_t *data, size_t len);
size_t jetrover_app_build_imu_packet(uint8_t *out, size_t capacity,
                                     float ax, float ay, float az,
                                     float gx, float gy, float gz);

#ifdef __cplusplus
}
#endif

#endif
