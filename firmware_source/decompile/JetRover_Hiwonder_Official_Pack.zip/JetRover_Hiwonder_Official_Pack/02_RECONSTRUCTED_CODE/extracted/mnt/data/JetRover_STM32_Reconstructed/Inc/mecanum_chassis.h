#ifndef JETROVER_MECANUM_CHASSIS_H
#define JETROVER_MECANUM_CHASSIS_H

#include "encoder_motor.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    EncoderMotor *motors[4];
    float wheel_diameter_mm;
    float shaft_length_mm;
    float wheelbase_mm;
    float correction_factor;
} MecanumChassis;

enum {
    JETROVER_MOTOR_1 = 0,
    JETROVER_MOTOR_2 = 1,
    JETROVER_MOTOR_3 = 2,
    JETROVER_MOTOR_4 = 3
};

void mecanum_chassis_init(MecanumChassis *chassis,
                          EncoderMotor *m1,
                          EncoderMotor *m2,
                          EncoderMotor *m3,
                          EncoderMotor *m4,
                          float wheel_diameter_mm,
                          float shaft_length_mm,
                          float wheelbase_mm,
                          float correction_factor);

/* vx/vy: mm/s, angular_rate: rad/s */
void mecanum_chassis_set_velocity(MecanumChassis *chassis,
                                  float vx_mm_s,
                                  float vy_mm_s,
                                  float angular_rate_rad_s);
void mecanum_chassis_stop(MecanumChassis *chassis);

#ifdef __cplusplus
}
#endif

#endif
