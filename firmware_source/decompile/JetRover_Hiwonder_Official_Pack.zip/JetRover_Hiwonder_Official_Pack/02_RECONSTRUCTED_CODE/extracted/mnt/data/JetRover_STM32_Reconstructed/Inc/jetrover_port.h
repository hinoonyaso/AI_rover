#ifndef JETROVER_PORT_H
#define JETROVER_PORT_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Implement these functions for the exact STM32CubeMX project/pinout. */
void jetrover_port_init(void);
void jetrover_port_set_motor_pwm(uint8_t motor_index, int pulse);
int64_t jetrover_port_read_encoder_counter(uint8_t motor_index);
bool jetrover_port_encoder_counting_down(uint8_t motor_index);
bool jetrover_port_motor_fault_active(uint8_t motor_index);
int jetrover_port_uart_write(const uint8_t *data, size_t len);
uint32_t jetrover_port_millis(void);

#ifdef __cplusplus
}
#endif

#endif
