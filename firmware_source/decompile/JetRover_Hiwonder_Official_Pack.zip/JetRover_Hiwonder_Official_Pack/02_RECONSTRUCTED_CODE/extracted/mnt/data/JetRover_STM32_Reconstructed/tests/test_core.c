#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "pid.h"
#include "encoder_motor.h"
#include "mecanum_chassis.h"
#include "rrc_protocol.h"

static int last_pwm[4];
static void set_pulse(EncoderMotor *m, int pulse) { last_pwm[m->motor_index] = pulse; }
static bool no_fault(const EncoderMotor *m) { (void)m; return false; }
static int callback_count;
static void packet_cb(const RRC_Packet *p, void *u)
{
    (void)u;
    assert(p->function == RRC_FUNC_KEY);
    assert(p->length == 2);
    assert(p->data[0] == 0x12 && p->data[1] == 0x34);
    ++callback_count;
}

int main(void)
{
    /* Verify CRC implementation against the lookup table recovered from firmware. */
    const uint8_t crc_sample[] = {0x06, 0x02, 0x12, 0x34};
    const uint8_t crc = rrc_crc8(crc_sample, sizeof(crc_sample));

    uint8_t frame[32];
    const uint8_t payload[] = {0x12, 0x34};
    const size_t n = rrc_encode_packet(frame, sizeof(frame), RRC_FUNC_KEY, payload, sizeof(payload));
    assert(n == 7);
    assert(frame[0] == 0xAA && frame[1] == 0x55);
    assert(frame[6] == crc);

    RRC_Parser parser;
    rrc_parser_init(&parser);
    rrc_parser_set_callback(&parser, RRC_FUNC_KEY, packet_cb, NULL);
    for (size_t i = 0; i < n; ++i) (void)rrc_parser_feed_byte(&parser, frame[i]);
    assert(callback_count == 1);

    EncoderMotor motors[4];
    for (unsigned i = 0; i < 4; ++i) {
        encoder_motor_init(&motors[i], (uint8_t)i, 1320.0f, 1.5f,
                           63.0f, 2.6f, 2.4f, set_pulse, no_fault);
    }
    MecanumChassis chassis;
    mecanum_chassis_init(&chassis, &motors[0], &motors[1], &motors[2], &motors[3],
                         97.0f, 195.0f, 216.0f, 1.0f);
    mecanum_chassis_set_velocity(&chassis, 200.0f, 0.0f, 0.0f);
    for (unsigned i = 0; i < 4; ++i) {
        assert(fabsf(motors[i].pid_controller.set_point) > 0.1f);
    }

    puts("JetRover reconstructed core tests: PASS");
    return 0;
}
