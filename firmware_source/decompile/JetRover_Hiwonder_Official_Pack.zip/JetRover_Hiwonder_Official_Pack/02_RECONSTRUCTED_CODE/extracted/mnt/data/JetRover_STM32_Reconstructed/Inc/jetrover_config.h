#ifndef JETROVER_CONFIG_H
#define JETROVER_CONFIG_H

/* Values confirmed by the uploaded binary / Hiwonder STM32 documentation. */
#define JETROVER_CONTROL_PERIOD_S          0.01f
#define JETROVER_ENCODER_TIMER_OVERFLOW    60000
#define JETROVER_PWM_LIMIT                 1000
#define JETROVER_PWM_DEAD_ZONE             250

/* Hiwonder JGB520/JGB528 example parameters. Verify against the exact motor fitted to your JetRover. */
#define JETROVER_MOTOR_TICKS_PER_REV       1320.0f
#define JETROVER_MOTOR_PID_KP              63.0f
#define JETROVER_MOTOR_PID_KI              2.6f
#define JETROVER_MOTOR_PID_KD              2.4f
#define JETROVER_MOTOR_RPS_LIMIT           1.5f

/*
 * Geometry is hardware-version dependent and was NOT uniquely recoverable from the HEX.
 * These defaults match a commonly used Hiwonder JetAuto/JETAUTO 4WD Mecanum configuration.
 * Measure your actual JetRover and change these before closed-loop navigation calibration.
 */
#ifndef JETROVER_WHEEL_DIAMETER_MM
#define JETROVER_WHEEL_DIAMETER_MM         97.0f
#endif
#ifndef JETROVER_TRACK_WIDTH_MM
#define JETROVER_TRACK_WIDTH_MM            195.0f
#endif
#ifndef JETROVER_WHEELBASE_MM
#define JETROVER_WHEELBASE_MM              216.0f
#endif
#define JETROVER_KINEMATIC_CORRECTION      1.0f

#endif
