#include "pid.h"

void pid_controller_init(PID_Controller *pid, float kp, float ki, float kd)
{
    if (!pid) return;
    pid->set_point = 0.0f;
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;
    pid->previous_0_err = 0.0f;
    pid->previous_1_err = 0.0f;
    pid->output = 0.0f;
}

void pid_controller_reset(PID_Controller *pid)
{
    if (!pid) return;
    pid->previous_0_err = 0.0f;
    pid->previous_1_err = 0.0f;
    pid->output = 0.0f;
}

void pid_controller_update(PID_Controller *pid, float actual, float time_delta_s)
{
    if (!pid || time_delta_s <= 0.0f) return;

    const float err = pid->set_point - actual;
    const float integral = err * time_delta_s;
    const float derivative =
        (err - (2.0f * pid->previous_1_err) + pid->previous_0_err) / time_delta_s;

    pid->output = (pid->kp * err) + (pid->ki * integral) + (pid->kd * derivative);
    pid->previous_1_err = pid->previous_0_err;
    pid->previous_0_err = err;
}
