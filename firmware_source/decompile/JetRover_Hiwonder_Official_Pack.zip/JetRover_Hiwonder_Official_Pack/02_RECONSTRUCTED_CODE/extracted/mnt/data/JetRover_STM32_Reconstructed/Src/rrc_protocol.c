#include "rrc_protocol.h"
#include <string.h>

/* CRC-8/MAXIM, reflected polynomial 0x8C. This exactly reproduces the table in the uploaded binary. */
uint8_t rrc_crc8(const uint8_t *data, size_t len)
{
    uint8_t crc = 0;
    if (!data && len) return 0;

    for (size_t i = 0; i < len; ++i) {
        crc ^= data[i];
        for (unsigned bit = 0; bit < 8; ++bit) {
            crc = (crc & 1u) ? (uint8_t)((crc >> 1) ^ 0x8Cu)
                             : (uint8_t)(crc >> 1);
        }
    }
    return crc;
}

void rrc_parser_init(RRC_Parser *parser)
{
    if (!parser) return;
    memset(parser, 0, sizeof(*parser));
    parser->state = RRC_RX_WAIT_AA;
}

void rrc_parser_set_callback(RRC_Parser *parser,
                             RRC_Function function,
                             RRC_PacketCallback callback,
                             void *user)
{
    if (!parser || function >= RRC_FUNC_NONE) return;
    parser->callbacks[function] = callback;
    parser->callback_users[function] = user;
}

static void parser_reset(RRC_Parser *parser)
{
    parser->state = RRC_RX_WAIT_AA;
    parser->payload_index = 0;
    parser->packet.function = 0;
    parser->packet.length = 0;
}

bool rrc_parser_feed_byte(RRC_Parser *parser, uint8_t byte)
{
    if (!parser) return false;

    switch (parser->state) {
    case RRC_RX_WAIT_AA:
        parser->state = (byte == RRC_HEADER_0) ? RRC_RX_WAIT_55 : RRC_RX_WAIT_AA;
        break;

    case RRC_RX_WAIT_55:
        parser->state = (byte == RRC_HEADER_1) ? RRC_RX_FUNCTION : RRC_RX_WAIT_AA;
        break;

    case RRC_RX_FUNCTION:
        if (byte < RRC_FUNC_NONE) {
            parser->packet.function = byte;
            parser->state = RRC_RX_LENGTH;
        } else {
            parser_reset(parser);
        }
        break;

    case RRC_RX_LENGTH:
        parser->packet.length = byte;
        parser->payload_index = 0;
        parser->state = (byte == 0) ? RRC_RX_CRC : RRC_RX_PAYLOAD;
        break;

    case RRC_RX_PAYLOAD:
        parser->packet.data[parser->payload_index++] = byte;
        if (parser->payload_index >= parser->packet.length) {
            parser->state = RRC_RX_CRC;
        }
        break;

    case RRC_RX_CRC: {
        uint8_t crc_buf[2 + RRC_MAX_PAYLOAD];
        crc_buf[0] = parser->packet.function;
        crc_buf[1] = parser->packet.length;
        if (parser->packet.length) {
            memcpy(&crc_buf[2], parser->packet.data, parser->packet.length);
        }
        const uint8_t expected = rrc_crc8(crc_buf, (size_t)parser->packet.length + 2u);
        const bool valid = (expected == byte);
        if (valid && parser->packet.function < RRC_FUNC_NONE) {
            RRC_PacketCallback cb = parser->callbacks[parser->packet.function];
            if (cb) cb(&parser->packet, parser->callback_users[parser->packet.function]);
        }
        parser_reset(parser);
        return valid;
    }

    default:
        parser_reset(parser);
        break;
    }
    return false;
}

size_t rrc_encode_packet(uint8_t *out,
                         size_t out_capacity,
                         RRC_Function function,
                         const void *payload,
                         uint8_t payload_len)
{
    const size_t frame_len = (size_t)payload_len + 5u;
    if (!out || out_capacity < frame_len || function >= RRC_FUNC_NONE) return 0;
    if (payload_len && !payload) return 0;

    out[0] = RRC_HEADER_0;
    out[1] = RRC_HEADER_1;
    out[2] = (uint8_t)function;
    out[3] = payload_len;
    if (payload_len) memcpy(&out[4], payload, payload_len);
    out[4u + payload_len] = rrc_crc8(&out[2], (size_t)payload_len + 2u);
    return frame_len;
}
