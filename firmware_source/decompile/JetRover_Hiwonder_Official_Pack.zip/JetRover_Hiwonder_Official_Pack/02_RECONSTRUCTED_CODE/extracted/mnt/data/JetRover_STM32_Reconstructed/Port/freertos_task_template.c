/* CMSIS-RTOS2 task skeleton using names recovered verbatim from the uploaded firmware. */
#ifdef JETROVER_USE_CMSIS_RTOS2
#include "cmsis_os2.h"
#include "jetrover_app.h"
#include "jetrover_port.h"

extern JetRoverApp g_jetrover;

void defaultTask(void *argument)
{
    (void)argument;
    for (;;) osDelay(1000);
}

void app_task(void *argument)
{
    (void)argument;
    for (;;) {
        /* gamepad/app/chassis supervisory logic */
        osDelay(10);
    }
}

void imu_task(void *argument)
{
    (void)argument;
    for (;;) {
        /* Wait for mpu6050_data_ready semaphore, sample IMU, transmit RRC_FUNC_IMU. */
        osDelay(1);
    }
}

void packet_rx_task(void *argument)
{
    (void)argument;
    for (;;) {
        /* Wait for packet_rx_not_empty semaphore; feed received UART bytes to jetrover_app_feed_uart(). */
        osDelay(1);
    }
}

void packet_tx_task(void *argument)
{
    (void)argument;
    for (;;) {
        /* Wait for packet_tx_queue; send frame using UART DMA. */
        osDelay(1);
    }
}

void sbus_rx_task(void *argument) { (void)argument; for (;;) osDelay(2); }
void gui_task(void *argument)     { (void)argument; for (;;) osDelay(10); }
void bluetooth_task(void *argument){ (void)argument; for (;;) osDelay(2); }
void oled_task(void *argument)    { (void)argument; for (;;) osDelay(100); }
#endif
