#include "jetrover_app.h"
#include "jetrover_config.h"
#include "jetrover_port.h"
#include <string.h>

static void motor_set_pulse_adapter(EncoderMotor *motor, int pulse)
{
    jetrover_port_set_motor_pwm(motor->motor_index, pulse);
}

static bool motor_fault_adapter(const EncoderMotor *motor)
{
    return jetrover_port_motor_fault_active(motor->motor_index);
}

static void motor_packet_callback(const RRC_Packet *packet, void *user)
{
    JetRoverApp *app = (JetRoverApp *)user;
    if (!app || !packet || packet->length < 1u) return;

    /*
     * Command IDs inferred from the Hiwonder firmware handler family:
     * 0: set one motor, 1: set multiple motors, 2: stop one, 3: stop multiple.
     * Exact payload layout varies by firmware generation, so only a conservative
     * emergency-stop command is enabled here. Extend after capturing host traffic.
     */
    const uint8_t command = packet->data[0];
    if (command == 3u) {
        jetrover_app_stop(app);
    }
}

void jetrover_app_init(JetRoverApp *app)
{
    if (!app) return;
    memset(app, 0, sizeof(*app));

    jetrover_port_init();
    for (uint8_t i = 0; i < 4; ++i) {
        encoder_motor_init(&app->motors[i], i,
                           JETROVER_MOTOR_TICKS_PER_REV,
                           JETROVER_MOTOR_RPS_LIMIT,
                           JETROVER_MOTOR_PID_KP,
                           JETROVER_MOTOR_PID_KI,
                           JETROVER_MOTOR_PID_KD,
                           motor_set_pulse_adapter,
                           motor_fault_adapter);
        app->motors[i].ticks_overflow = JETROVER_ENCODER_TIMER_OVERFLOW;
    }

    mecanum_chassis_init(&app->chassis,
                         &app->motors[0], &app->motors[1],
                         &app->motors[2], &app->motors[3],
                         JETROVER_WHEEL_DIAMETER_MM,
                         JETROVER_TRACK_WIDTH_MM,
                         JETROVER_WHEELBASE_MM,
                         JETROVER_KINEMATIC_CORRECTION);

    rrc_parser_init(&app->packet_parser);
    rrc_parser_set_callback(&app->packet_parser, RRC_FUNC_MOTOR,
                            motor_packet_callback, app);
}

void jetrover_app_set_cmd_vel(JetRoverApp *app, float vx_m_s, float vy_m_s, float wz_rad_s)
{
    if (!app) return;
    mecanum_chassis_set_velocity(&app->chassis,
                                 vx_m_s * 1000.0f,
                                 vy_m_s * 1000.0f,
                                 wz_rad_s);
}

void jetrover_app_stop(JetRoverApp *app)
{
    if (!app) return;
    mecanum_chassis_stop(&app->chassis);
    for (unsigned i = 0; i < 4; ++i) encoder_motor_stop(&app->motors[i]);
}

void jetrover_app_control_tick_10ms(JetRoverApp *app)
{
    if (!app) return;
    for (uint8_t i = 0; i < 4; ++i) {
        const int64_t counter = jetrover_port_read_encoder_counter(i);
        encoder_motor_update_speed(&app->motors[i], JETROVER_CONTROL_PERIOD_S, counter);
    }
    for (uint8_t i = 0; i < 4; ++i) {
        encoder_motor_control(&app->motors[i], JETROVER_CONTROL_PERIOD_S);
    }
}

void jetrover_app_encoder_overflow_isr(JetRoverApp *app, uint8_t motor_index)
{
    if (!app || motor_index >= 4u) return;
    encoder_motor_on_encoder_overflow(&app->motors[motor_index],
                                      jetrover_port_encoder_counting_down(motor_index));
}

void jetrover_app_feed_uart(JetRoverApp *app, const uint8_t *data, size_t len)
{
    if (!app || (!data && len)) return;
    for (size_t i = 0; i < len; ++i) {
        (void)rrc_parser_feed_byte(&app->packet_parser, data[i]);
    }
}

size_t jetrover_app_build_imu_packet(uint8_t *out, size_t capacity,
                                     float ax, float ay, float az,
                                     float gx, float gy, float gz)
{
    /* Uploaded firmware sends function 7 with a 7-byte payload, but the exact
       compact IMU encoding is firmware-version specific. Do not fabricate it. */
    (void)out; (void)capacity; (void)ax; (void)ay; (void)az; (void)gx; (void)gy; (void)gz;
    return 0;
}
