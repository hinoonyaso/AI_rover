#ifndef JETROVER_USE_STM32_HAL
#include "jetrover_port.h"
#include <time.h>

static int pwm_value[4];
static int64_t encoder_value[4];

void jetrover_port_init(void) {}
void jetrover_port_set_motor_pwm(uint8_t motor_index, int pulse)
{
    if (motor_index < 4u) pwm_value[motor_index] = pulse;
}
int64_t jetrover_port_read_encoder_counter(uint8_t motor_index)
{
    return motor_index < 4u ? encoder_value[motor_index] : 0;
}
bool jetrover_port_encoder_counting_down(uint8_t motor_index)
{
    (void)motor_index; return false;
}
bool jetrover_port_motor_fault_active(uint8_t motor_index)
{
    (void)motor_index; return false;
}
int jetrover_port_uart_write(const uint8_t *data, size_t len)
{
    (void)data; return (int)len;
}
uint32_t jetrover_port_millis(void)
{
    return (uint32_t)((clock() * 1000u) / CLOCKS_PER_SEC);
}
#endif
