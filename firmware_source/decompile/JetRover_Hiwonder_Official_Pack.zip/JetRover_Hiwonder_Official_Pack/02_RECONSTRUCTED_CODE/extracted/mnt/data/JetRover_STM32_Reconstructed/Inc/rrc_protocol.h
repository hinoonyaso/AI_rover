#ifndef JETROVER_RRC_PROTOCOL_H
#define JETROVER_RRC_PROTOCOL_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define RRC_HEADER_0 0xAAu
#define RRC_HEADER_1 0x55u
#define RRC_MAX_PAYLOAD 255u

typedef enum {
    RRC_FUNC_SYS        = 0,
    RRC_FUNC_LED        = 1,
    RRC_FUNC_BUZZER     = 2,
    RRC_FUNC_MOTOR      = 3,
    RRC_FUNC_PWM_SERVO  = 4,
    RRC_FUNC_BUS_SERVO  = 5,
    RRC_FUNC_KEY        = 6,
    RRC_FUNC_IMU        = 7,
    RRC_FUNC_GAMEPAD    = 8,
    RRC_FUNC_SBUS       = 9,
    RRC_FUNC_NONE       = 10
} RRC_Function;

typedef struct {
    uint8_t function;
    uint8_t length;
    uint8_t data[RRC_MAX_PAYLOAD];
} RRC_Packet;

typedef void (*RRC_PacketCallback)(const RRC_Packet *packet, void *user);

typedef enum {
    RRC_RX_WAIT_AA = 0,
    RRC_RX_WAIT_55,
    RRC_RX_FUNCTION,
    RRC_RX_LENGTH,
    RRC_RX_PAYLOAD,
    RRC_RX_CRC
} RRC_RxState;

typedef struct {
    RRC_RxState state;
    RRC_Packet packet;
    uint16_t payload_index;
    RRC_PacketCallback callbacks[RRC_FUNC_NONE];
    void *callback_users[RRC_FUNC_NONE];
} RRC_Parser;

uint8_t rrc_crc8(const uint8_t *data, size_t len);
void rrc_parser_init(RRC_Parser *parser);
void rrc_parser_set_callback(RRC_Parser *parser,
                             RRC_Function function,
                             RRC_PacketCallback callback,
                             void *user);
bool rrc_parser_feed_byte(RRC_Parser *parser, uint8_t byte);
size_t rrc_encode_packet(uint8_t *out,
                         size_t out_capacity,
                         RRC_Function function,
                         const void *payload,
                         uint8_t payload_len);

#ifdef __cplusplus
}
#endif

#endif
