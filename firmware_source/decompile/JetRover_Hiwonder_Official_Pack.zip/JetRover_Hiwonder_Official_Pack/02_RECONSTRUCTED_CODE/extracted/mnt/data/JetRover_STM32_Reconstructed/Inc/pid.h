#ifndef JETROVER_PID_H
#define JETROVER_PID_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float set_point;
    float kp;
    float ki;
    float kd;
    float previous_0_err;
    float previous_1_err;
    float output;
} PID_Controller;

void pid_controller_init(PID_Controller *pid, float kp, float ki, float kd);
void pid_controller_reset(PID_Controller *pid);
void pid_controller_update(PID_Controller *pid, float actual, float time_delta_s);

#ifdef __cplusplus
}
#endif

#endif
