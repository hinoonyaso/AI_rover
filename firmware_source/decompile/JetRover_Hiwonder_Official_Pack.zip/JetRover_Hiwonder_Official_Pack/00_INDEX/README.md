# JetRover / HiWonder STM32 Reverse-Engineering Research Pack

생성일: 2026-10-05

이 묶음은 JetRover의 STM32 저수준 제어기 분석/복원 작업을 위한 자료를 한곳에 정리한 것이다.

## 포함된 파일

- `01_USER_DECOMPILE/`: 사용자가 제공한 Ghidra decompile 결과와 원본 HEX/BIN
- `02_RECONSTRUCTED_CODE/`: 재구성한 모터/엔코더/PID/Mecanum/RRC C 코드
- `03_OFFICIAL_DOWNLOAD_SCRIPTS/`: HiWonder 공식 GitHub/Google Drive 자료를 한 번에 받는 스크립트
- `04_OFFICIAL_FILES_DOWNLOADED/`: 현재 세션에서 직접 확보 가능한 공식 파일을 넣는 위치
- `05_REFERENCE/`: 공식 출처 URL, 기능별 근거, 다운로드 상태

## 중요

HiWonder의 ROS Robot Control Board 전체 개발 패키지는 공식 문서의 Appendix에서 Google Drive 폴더로 배포된다. 현재 ChatGPT 작업 환경은 해당 Drive 폴더 내부의 바이너리 ZIP/PDF를 직접 materialize할 수 없으므로, 이 ZIP에는 공식 다운로드 위치와 자동 다운로드 스크립트를 포함했다.

인터넷이 연결된 Ubuntu/WSL에서 아래를 실행하면 공식 GitHub 문서 저장소와 Drive 자료까지 `official_downloads/` 아래에 수집된다.

```bash
cd 03_OFFICIAL_DOWNLOAD_SCRIPTS
bash download_all_official.sh
```

## 권장 분석 순서

1. `01_USER_DECOMPILE/extracted/decompile/`의 HEX/BIN/Decompiler 결과 확인
2. `02_RECONSTRUCTED_CODE/`의 재구성 코드와 비교
3. 공식 `ROS-Robot-Control-Board` 문서/코드에서 함수명과 HW pin을 대조
4. 실제 JetRover PCB revision과 GPIO/TIM/UART mapping을 확인
5. Motor/Encoder/PID → IMU → Battery → RRC → micro-ROS 순으로 통합
