#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-official_github}"
mkdir -p "$ROOT"
git clone --depth 1 https://github.com/Hiwonder-docs/ROS-Robot-Control-Board.git "$ROOT/ROS-Robot-Control-Board"
git clone --depth 1 https://github.com/Hiwonder-docs/JetRover.git "$ROOT/JetRover"
git clone --depth 1 https://github.com/Hiwonder-docs/ROSOrin.git "$ROOT/ROSOrin"
git clone --depth 1 https://github.com/Hiwonder/ROSOrin-Pro.git "$ROOT/ROSOrin-Pro"
