#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-official_downloads}"
mkdir -p "$ROOT/github" "$ROOT/google_drive"

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || return 1
}

if ! need_cmd git; then
  echo "[ERROR] git이 필요하다: sudo apt install git"
  exit 1
fi

clone_or_update() {
  local url="$1"
  local dst="$2"
  if [ -d "$dst/.git" ]; then
    echo "[UPDATE] $dst"
    git -C "$dst" pull --ff-only || true
  else
    echo "[CLONE] $url"
    git clone --depth 1 "$url" "$dst"
  fi
}

clone_or_update https://github.com/Hiwonder-docs/ROS-Robot-Control-Board.git "$ROOT/github/ROS-Robot-Control-Board"
clone_or_update https://github.com/Hiwonder-docs/JetRover.git "$ROOT/github/JetRover"
clone_or_update https://github.com/Hiwonder-docs/ROSOrin.git "$ROOT/github/ROSOrin"
clone_or_update https://github.com/Hiwonder/ROSOrin-Pro.git "$ROOT/github/ROSOrin-Pro"

# Google Drive public folder downloader
if ! need_cmd gdown; then
  echo "[INFO] gdown이 없어 설치를 시도한다."
  python3 -m pip install --user -U gdown
  export PATH="$HOME/.local/bin:$PATH"
fi

if need_cmd gdown; then
  echo "[GDRIVE] ROS Robot Control Board full resources v1.2"
  gdown --folder --remaining-ok \
    "https://drive.google.com/drive/folders/1ITrr0a_EAi3al5hOrIHmCNFlZunjZ0LM?usp=sharing" \
    -O "$ROOT/google_drive/ROS_Robot_Control_Board_v1.2" || true

  echo "[GDRIVE] ROS Development Package"
  gdown --folder --remaining-ok \
    "https://drive.google.com/drive/folders/17ggHEm5_7h9G88w34UDYsoXMjX7rR21l?usp=sharing" \
    -O "$ROOT/google_drive/ROS_Development_Package" || true

  echo "[GDRIVE] Appendix / firmware / drawings"
  gdown --folder --remaining-ok \
    "https://drive.google.com/drive/folders/1Ebhqdic1G7MTrq-KN6KckFSHEi7Ii7yx?usp=sharing" \
    -O "$ROOT/google_drive/Appendix" || true
else
  echo "[WARN] gdown 설치 실패. Google Drive 자료는 브라우저에서 직접 내려받아야 한다."
fi

echo
echo "완료: $ROOT"
find "$ROOT" -maxdepth 3 -type f | sort | sed -n '1,200p'
