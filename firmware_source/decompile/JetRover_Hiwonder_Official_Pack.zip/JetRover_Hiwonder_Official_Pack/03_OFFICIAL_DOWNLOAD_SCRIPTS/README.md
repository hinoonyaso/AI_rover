# 공식 자료 자동 다운로드

Ubuntu/WSL 권장:

```bash
bash download_all_official.sh
```

GitHub 문서/코드만 받을 경우:

```bash
bash download_github_only.sh
```

Google Drive 폴더는 HiWonder 공식 Appendix가 직접 링크한 public resource folder이다. `gdown`이 Drive 정책 변화 때문에 실패하면 `05_REFERENCE/OFFICIAL_SOURCES.md`의 링크를 브라우저로 열어 폴더 전체 다운로드를 사용한다.
