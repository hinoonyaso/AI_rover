# HiWonder 공식 출처 인덱스

## ROS Robot Control Board

- Main documentation:
  https://wiki.hiwonder.com/projects/ROS-Robot-Control-Board/en/latest/
- Hardware course:
  https://wiki.hiwonder.com/projects/ROS-Robot-Control-Board/en/latest/docs/1_Controller_Hardware_Course.html
- STM32 development fundamentals:
  https://wiki.hiwonder.com/projects/ROS-Robot-Control-Board/en/latest/docs/2_STM32_Development_Fundamentals.html
- Program analysis / source-code explanation:
  https://wiki.hiwonder.com/projects/ROS-Robot-Control-Board/en/latest/docs/3_RosRobot_Controller_Program_Analysis.html
- Appendix / official downloads:
  https://wiki.hiwonder.com/projects/ROS-Robot-Control-Board/en/latest/docs/Appendix.html
- Official docs GitHub:
  https://github.com/Hiwonder-docs/ROS-Robot-Control-Board

## Official Google Drive resource folders linked by HiWonder

- Full ROS Robot Control Board resources v1.2:
  https://drive.google.com/drive/folders/1ITrr0a_EAi3al5hOrIHmCNFlZunjZ0LM?usp=sharing
- ROS Development Package folder:
  https://drive.google.com/drive/folders/17ggHEm5_7h9G88w34UDYsoXMjX7rR21l?usp=sharing
- Appendix / firmware / drawing folder:
  https://drive.google.com/drive/folders/1Ebhqdic1G7MTrq-KN6KckFSHEi7Ii7yx?usp=sharing

The official Appendix states that these folders include at least:

- ros_robot_controller.zip
- ros_robot_controller-ros2.zip
- RRC Communication Protocol with the Host Computer Analysis.pdf
- 5-in-1 Switching Routine.zip
- 7-in-1 Switching Routine.zip
- RosRobotControllerM4.hex
- STM32.stp
- firmware-download/development tools

## JetRover

- JetRover Orin Nano Quick Start:
  https://wiki.hiwonder.com/projects/JetRover/en/jetson-orin-nano/docs/1.Quick_Start_Guide.html
- JetRover Jetson Nano Quick Start:
  https://wiki.hiwonder.com/projects/JetRover/en/jetrover-jetson-nano/docs/1_Quick_Start_Guide.html
- Official JetRover docs GitHub:
  https://github.com/Hiwonder-docs/JetRover

## Related official STM32 / Mecanum reference

- Black Mecanum Wheel Chassis STM32 tutorial:
  https://docs.hiwonder.com/projects/Black-Mecanum-Wheel-Chassis/en/latest/docs/2_STM32_checked.html
- ROSOrin official docs GitHub:
  https://github.com/Hiwonder-docs/ROSOrin
- ROSOrin User Manual:
  https://github.com/Hiwonder-docs/ROSOrin/blob/main/source/docs/1_ROSOrin_User_Manual.md
- ROSOrin-Pro official repo / factory STM32 firmware:
  https://github.com/Hiwonder/ROSOrin-Pro
- Current public factory firmware example:
  https://github.com/Hiwonder/ROSOrin-Pro/blob/jetson-nano/STM32/RosRobotControllerM4-20260414.hex
