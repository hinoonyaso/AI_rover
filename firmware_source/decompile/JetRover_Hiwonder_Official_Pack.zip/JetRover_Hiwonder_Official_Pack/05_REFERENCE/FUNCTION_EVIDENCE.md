# 기능별 공식자료 대조 포인트

## Low-level controller
STM32F407VET6가 모터 제어, encoder, IMU, LED, buzzer, USB HOST gamepad, SBUS, serial communication 등을 담당한다.

## Motor / Encoder / PID
공식 Program Analysis와 Black Mecanum Wheel Chassis 문서에서 DC motor, AB encoder, PID, chassis kinematics 관련 구현 구조를 확인할 수 있다.

## IMU
ROS Robot Control Board revision에 따라 공식 문서에 MPU6050/QMI8658 관련 자료가 존재한다. 실제 JetRover 보드 revision과 사용자가 보유한 펌웨어의 문자열/레지스터 접근을 함께 확인해야 한다.

## Battery
공식 Program Analysis에 ADC power-supply voltage detection 장이 있으며, 배터리 전압 측정과 필터링 로직을 제공한다.

## LED / Buzzer
공식 Program Analysis에 LED/Buzzer source-code analysis가 있으며 FreeRTOS timer/queue 기반 제어 구조를 확인할 수 있다.

## Gamepad
공식 Program Analysis의 PS2 Controller USB Receiver Signal Processing 장에서 USB HOST/HID 처리 구조를 확인할 수 있다.

## SBUS
공식 Program Analysis의 SBUS reception 장에서 UART/DMA/frame 처리 구조를 확인할 수 있다.

## RRC protocol
공식 Program Analysis 3.14~3.16 및 별도 RRC Communication Protocol PDF에서 packet format, TX/RX processing을 확인할 수 있다.
