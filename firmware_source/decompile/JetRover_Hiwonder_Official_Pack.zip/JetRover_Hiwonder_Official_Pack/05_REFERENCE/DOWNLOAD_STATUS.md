# 다운로드 상태

## ZIP에 실제 포함됨

- 사용자 제공 `decompile.zip` 전체
- 사용자 펌웨어 `RosRobotControllerM4.hex` / `.bin` (decompile archive 내부)
- Ghidra decompiled C / disassembly / functions / strings / vectors
- 재구성한 STM32 C 프로젝트 전체

## 공식 다운로드 위치까지 확인됨

- HiWonder ROS Robot Control Board docs repository
- HiWonder JetRover docs repository
- HiWonder ROSOrin docs repository
- HiWonder ROSOrin-Pro repository
- HiWonder Google Drive v1.2 resource folder
- ROS Development Package Drive folder
- Appendix / factory firmware / drawing Drive folder

## 현재 세션에서 직접 포함하지 못한 공식 바이너리

현재 작업 환경에서는 Google Drive shared folder 내부 파일을 직접 바이너리로 materialize할 수 없었다. 따라서 공식 ZIP/PDF/STEP/EXE 등은 `download_all_official.sh`를 실행해 원본 출처에서 받도록 구성했다.
